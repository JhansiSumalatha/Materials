package StockCompanyDistCacheJoinMapper;

public class StockCompanyDistCacheJoinMapper {

}
