./main.sh ${1} "grep ^%wheel /etc/sudoers"
