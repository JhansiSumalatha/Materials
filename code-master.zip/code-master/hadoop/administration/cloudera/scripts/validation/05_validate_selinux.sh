./main.sh ${1} "grep -w ^SELINUX /etc/selinux/config"
