./main.sh ${1} "id hduser"
